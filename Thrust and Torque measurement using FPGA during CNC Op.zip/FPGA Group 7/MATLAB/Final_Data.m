%% The above codes are taken from the Mathworks and Mark Quinn, Experimental Methods, University of Manchester
%% Factorial matrix for the experiment: Drilling of holes in workpiece
% Parameters used are:
% Drilling Speed (rpm): 3 levels: 1700 2450 3190
% Drill Feed (mm/min): 3 levels: 267 380 496
% Design of experiment
% Based on above parameters, we have 2 parameters varying in 3 levels
% Reference: From Factorial matrix Mark Quinn University of Manchester
levels =[3 3];
fact_mat=fullfact(levels);
barh(fact_mat);
xlabel('Levels');
ylabel('Runs');
legend('Speed(RPM) 1:1700 2: 2450 3: 3190','Feed(mm/min) 1: 267 2: 380 3: 496');
title('Factorial Matrix');
figure;

%% To read a File and import the data follow the steps mentioned below the line
uiimport('Dataset.xlsx'); 
% Select the options variable row names from selection, 
% change imported data output type to column vectors
% Select import data from import selection drop-down menu
%% To save the variables in the workspace as a matlab data file
% save('Data_variables','AI0','AI1');
%% To load the variables and plot experiment data
% For the Torque values from AI0,
v1=AI0+84; % This is to bring plot the data from 0
v1=v1*(200*10)/2048; %Converts from binary to Ncm
% For the thrust values from AI1,
v2=AI1+194; % This is to bring plot the data from 0
v2=v2*(500*10)/2048;%Converts from binary to Ncm
AI0=AI0+84;
AI1=AI1+194;
Fs=10000; % Data recording frequency
t=((0:length(AI0)-1)/Fs);
b1=v1(217500:236000,1);
t2=((0:length(b1)-1)/Fs);
plot(t2,b1,'o')

%% To perform the uncertainity levels with 95% confidence levels (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester,2021)
cl=[0.95];
%% For the Data Analysis of Torque signal: 1st experiment
% Splitting data into 9 dataM_V1=v1(154000:180000,1); % To split the data into range for 1st dataset
M_V1=v1(154000:180000,1);   % (Mathworks website, 2021)
t2=((0:length(M_V1)-1)/Fs);
plot(t2,M_V1);

%% To split the data into range for 1st dataset
M_V1=v1(154000:180000,1);
t2=((0:length(M_V1)-1)/Fs);
a=max(M_V1)
plot(t2,M_V1,'o')

% To filter the data at machining range
filtered_M_V1_Idx = find((M_V1>=200 & M_V1<=800)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_V1 = M_V1(M_V1>=200 & M_V1<=800);
r1=length(filtered_M_V1);

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s1=1:r1;
order1=1;
t1=((0:length(filtered_M_V1)-1)/Fs);
T1=polyfit(x_s1,filtered_M_V1,order1);
f1=(polyval(T1,x_s1))';
figure
plot(t1,filtered_M_V1);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 1')
hold on
plot(t1,f1,'r');
hold off
figure;

% To plot the residuals of the graph:
res1=(filtered_M_V1-(f1));
plot(t1,res1,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 1')

% To print residuals
Sres1=sum((filtered_M_V1-(f1)).^2);
St1=sum((filtered_M_V1-mean(filtered_M_V1)).^2);
RSq1=1-Sres1/St1

% Carrying out uncertainity analysis and print out error at 95% confidence
% (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor1=tinv((cl+1)./2,r1-1);
Sx1=std(res1);
Sx_1=tfactor1*Sx1/r1^0.5;
Calib_error1=Sx_1/mean(filtered_M_V1)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v1=filtered_M_V1; % To find the mean amplitude
F_v1=detrend(filtered_M_V1); % To find the signal amplitude or 
% F_v1=res1; same as detrend with polyorder 1
Fourier_1=fft(F_v1,length(F_v1));
Fourier_t1=abs(Fourier_1/length(F_v1));
F_t1 = Fourier_t1(1:(length(F_v1)/2)+1);
F_t1(2:end-1) = 2*F_t1(2:end-1);
l1=Fs*(0:(length(F_v1)/2))/length(F_v1);
figure
plot(l1,F_t1);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 1')

%% For 2nd experiment
M_V2=v1(217500:236000,1);
filtered_M_V2_Idx = find((M_V2>=200 & M_V2<=1000)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_V2 = M_V2(M_V2>200 & M_V2<=1000);
r2=length(filtered_M_V2);
b=max(M_V2);

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s2=1:r2;
order2=1;
t2=((0:length(filtered_M_V2)-1)/Fs);
T2=polyfit(x_s2,filtered_M_V2,order2);
f2=(polyval(T2,x_s2))';
figure;
plot(t2,filtered_M_V2);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 2')
hold on
plot(t2,f2,'r');
hold off
figure;

% to plot the residuals of the graph:
res2=(filtered_M_V2-(f2));
plot(res2,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 2')

% to print residuals
Sres2=sum((filtered_M_V2-(f2)).^2);
St2=sum((filtered_M_V2-mean(filtered_M_V2)).^2);
RSq2=1-Sres2/St2

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor2=tinv((cl+1)./2,r2-1);
Sx2=std(res2);
Sx_2=tfactor2*Sx2/r2^0.5;
Calib_error2=Sx_2/mean(filtered_M_V2)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v2=filtered_M_V2; % To find the mean amplitude
F_v2=detrend(filtered_M_V2); % To find the signal amplitude or 
% F_v2=res2; same as detrend with polyorder 1
Fourier_2=fft(F_v2);
Fourier_t2=abs(Fourier_2/length(F_v2));
F_t2 = Fourier_t2(1:(length(F_v2)/2)+1);
F_t2(2:end-1) = 2*F_t2(2:end-1);
l2=Fs*(0:(length(F_v2)/2))/length(F_v2);
figure
plot(l2,F_t2);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 2')

%% For the 3rd experiment
M_V3=v1(268000:282000,1);
filtered_M_V3_Idx = find((M_V3>=300 & M_V3<=1200)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_V3 = M_V3(M_V3>300 & M_V3<=1200);
r3=length(filtered_M_V3);
c=max(M_V3)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s3=1:r3;
order3=1;
t3=((0:length(filtered_M_V3)-1)/Fs);
T3=polyfit(x_s3,filtered_M_V3,order3);
f3=(polyval(T3,x_s3))';
figure;
plot(t3,filtered_M_V3);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 3')
hold on
plot(t3,f3,'r');
hold off
figure;

% To plot the residuals of the graph:
res3=(filtered_M_V3-(f3));
plot(res3,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 3')

% To print residuals
Sres3=sum((filtered_M_V3-(f3)).^2);
St3=sum((filtered_M_V3-mean(filtered_M_V3)).^2);
RSq3=1-Sres3/St3

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor3=tinv((cl+1)./2,r3-1);
Sx3=std(res3);
Sx_3=tfactor3*Sx3/r3^0.5;
Calib_error3=Sx_3/mean(filtered_M_V3)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v3=filtered_M_V3; % To find the mean amplitude
F_v3=detrend(filtered_M_V3); % To find the signal amplitude or 
% F_v3=res3; %same as detrend with polyorder 1
Fourier_3=fft(F_v3);
Fourier_t3=abs(Fourier_3/length(F_v3));
F_t3 = Fourier_t3(1:(length(F_v3)/2)+1);
F_t3(2:end-1) = 2*F_t3(2:end-1);
l3=Fs*(0:(length(F_v3)/2))/length(F_v3);
figure
plot(l3,F_t3);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 3')

%% For the 4th experiment
M_V4=v1(322000:350000,1);
filtered_M_V4_Idx = find((M_V4>=200 & M_V4<=1200)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_V4 = M_V4(M_V4>200 & M_V4<=1200);
r4=length(filtered_M_V4);
d=max(M_V4)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s4=1:r4;
order4=1;
t4=((0:length(filtered_M_V4)-1)/Fs);
T4=polyfit(x_s4,filtered_M_V4,order4);
f4=(polyval(T4,x_s4))';
figure;
plot(t4,filtered_M_V4);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 4')
hold on
plot(t4,f4,'r');
hold off
figure;

% To plot the residuals of the graph:
res4=(filtered_M_V4-(f4));
plot(res4,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 4')

% To print residuals
Sres4=sum((filtered_M_V4-(f4)).^2);
St4=sum((filtered_M_V4-mean(filtered_M_V4)).^2);
RSq4=1-Sres4/St4

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor4=tinv((cl+1)./2,r4-1);
Sx4=std(res4);
Sx_4=tfactor4*Sx4/r4^0.5;
Calib_error4=Sx_4/mean(filtered_M_V4)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v4=filtered_M_V4; %To find the mean amplitude
F_v4=detrend(filtered_M_V4); %To find the signal amplitude or 
% F_v4=res4; % same as detrend with polyorder 1
Fourier_4=fft(F_v4);
Fourier_t4=abs(Fourier_4/length(F_v4));
F_t4 = Fourier_t4(1:(length(F_v4)/2)+1);
F_t4(2:end-1) = 2*F_t4(2:end-1);
l4=Fs*(0:(length(F_v4)/2))/length(F_v4);
figure
plot(l4,F_t4);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 4') 

%% For the 5th experiment
M_V5=v1(383000:401500,1);tor-of-thousand-rows
filtered_M_V5 = M_V5(M_V5>200 & M_V5<=1200);
r5=length(filtered_M_V5);
e=max(M_V5)
filtered_M_V5_Idx = find((M_V5>=200 & M_V5<=1200)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vec)

% To plot the individual data series along with curve ftting (Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s5=1:r5;
order5=1;
t5=((0:length(filtered_M_V5)-1)/Fs);
T5=polyfit(x_s5,filtered_M_V5,order5);
f5=(polyval(T5,x_s5))';
figure;
plot(t5,filtered_M_V5);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 5')
hold on
plot(t5,f5,'r');
hold off
figure;

% To plot the residuals of the graph:
res5=(filtered_M_V5-(f5));
plot(res5,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 5')

% To print residuals
Sres5=sum((filtered_M_V5-(f5)).^2);
St5=sum((filtered_M_V5-mean(filtered_M_V5)).^2);
RSq5=1-Sres5/St5

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor5=tinv((cl+1)./2,r5-1);
Sx5=std(res5);
Sx_5=tfactor5*Sx5/r5^0.5;
Calib_error5=Sx_5/mean(filtered_M_V5)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v5=filtered_M_V5; %To find the mean amplitude
F_v5=detrend(filtered_M_V5); % To find the signal amplitude or 
% F_v5=res5; %same as detrend with polyorder
Fourier_5=fft(F_v5);
Fourier_t5=abs(Fourier_5/length(F_v5));
F_t5 = Fourier_t5(1:(length(F_v5)/2)+1);
F_t5(2:end-1) = 2*F_t5(2:end-1);
l5=Fs*(0:(length(F_v5)/2))/length(F_v5);
figure
plot(l5,F_t5);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 5')

%% For the 6th experiment
M_V6=v1(439000:454000,1);
filtered_M_V6_Idx = find((M_V6>=300 & M_V6<=1200)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_V6 = M_V6(M_V6>300 & M_V6<=1200);
r6=length(filtered_M_V6);
f=max(M_V6)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s6=1:r6;
order6=1;
t6=((0:length(filtered_M_V6)-1)/Fs);
T6=polyfit(x_s6,filtered_M_V6,order6);
f6=(polyval(T6,x_s6))';
figure;
plot(t6,filtered_M_V6);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 6')
hold on
plot(t6,f6,'r');
hold off
figure;

% To plot the residuals of the graph:
res6=(filtered_M_V6-(f6));
plot(res6,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 6')

% To print residuals
Sres6=sum((filtered_M_V6-(f6)).^2);
St6=sum((filtered_M_V6-mean(filtered_M_V6)).^2);
RSq6=1-Sres6/St6

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor6=tinv((cl+1)./2,r6-1);
Sx6=std(res6);
Sx_6=tfactor6*Sx6/r6^0.5;
Calib_error6=Sx_6/mean(filtered_M_V6)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v6=filtered_M_V6; % To find the mean amplitude
F_v6=detrend(filtered_M_V6); % To find the signal amplitude or 
% F_v6=res6; %same as detrend with polyorder 1
Fourier_6=fft(F_v6);
Fourier_t6=abs(Fourier_6/length(F_v6));
F_t6 = Fourier_t6(1:(length(F_v6)/2)+1);
F_t6(2:end-1) = 2*F_t6(2:end-1);
l6=Fs*(0:(length(F_v6)/2))/length(F_v6);
figure
plot(l6,F_t6);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 6')

%% For the 7th experiment
M_V7=v1(493500:525000,1);
filtered_M_V7_Idx = find((M_V7>=100 & M_V7<=1200)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_V7 = M_V7(M_V7>100 & M_V7<=1200);
r7=length(filtered_M_V7);
g=max(M_V7)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s7=1:r7;
order7=1;
t7=((0:length(filtered_M_V7)-1)/Fs);
T7=polyfit(x_s7,filtered_M_V7,order7);
f7=(polyval(T7,x_s7))';
figure;
plot(t7,filtered_M_V7);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 7')
hold on
plot(t7,f7,'r');
hold off
figure;

% To plot the residuals of the graph:
res7=(filtered_M_V7-(f7));
plot(res7,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 7')

% To print residuals
Sres7=sum((filtered_M_V7-(f7)).^2);
St7=sum((filtered_M_V7-mean(filtered_M_V7)).^2);
RSq7=1-Sres7/St7

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor7=tinv((cl+1)./2,r7-1);
Sx7=std(res7);
Sx_7=tfactor7*Sx7/r7^0.5;
Calib_error7=Sx_7/mean(filtered_M_V7)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v7=filtered_M_V7; %To find the mean amplitude
F_v7=detrend(filtered_M_V7); % To find the signal amplitude or 
% F_v7=res7; %same as detrend with polyorder 1
Fourier_7=fft(F_v7);
Fourier_t7=abs(Fourier_7/length(F_v7));
F_t7 = Fourier_t7(1:(length(F_v7)/2)+1);
F_t7(2:end-1) = 2*F_t7(2:end-1);
l7=Fs*(0:(length(F_v7)/2))/length(F_v7);
figure
plot(l7,F_t7);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 7')

%% For the 8th experiment
M_V8=v1(555000:575000,1);
filtered_M_V8_Idx = find((M_V8>=200 & M_V8<=1200));  % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_V8 = M_V8(M_V8>200 & M_V8<=1200);
r8=length(filtered_M_V8);
h=max(M_V8)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s8=1:r8;
order8=1;
t8=((0:length(filtered_M_V8)-1)/Fs);
T8=polyfit(x_s8,filtered_M_V8,order8);
f8=(polyval(T8,x_s8))';
figure;
plot(t8,filtered_M_V8);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 8')
hold on
plot(t8,f8,'r');
hold off
figure;

% To plot the residuals of the graph:
res8=(filtered_M_V8-(f8));
plot(res8,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 8')

% To print residuals
Sres8=sum((filtered_M_V8-(f8)).^2);
St8=sum((filtered_M_V8-mean(filtered_M_V8)).^2);
RSq8=1-Sres8/St8

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor8=tinv((cl+1)./2,r8-1);
Sx8=std(res8);
Sx_8=tfactor8*Sx8/r8^0.5;
Calib_error8=Sx_8/mean(filtered_M_V8)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v8=filtered_M_V8; %To find the mean amplitude
F_v8=detrend(filtered_M_V8); % To find the signal amplitude or 
%F_v8=res8; same as detrend with polyorder 1
Fourier_8=fft(F_v8);
Fourier_t8=abs(Fourier_8/length(F_v8));
F_t8 = Fourier_t8(1:(length(F_v8)/2)+1);
F_t8(2:end-1) = 2*F_t8(2:end-1);
l8=Fs*(0:(length(F_v8)/2))/length(F_v8);
figure
plot(l8,F_t8);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 8')

%% For the 9th experiment
M_V9=v1(600000:623000,1);
filtered_M_V9_Idx = find((M_V9>=200 & M_V9<=1200)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_V9 = M_V9(M_V9>200 & M_V9<=1200);
r9=length(filtered_M_V9);
i=max(M_V9)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_s9=1:r9;
order9=1;
t9=((0:length(filtered_M_V9)-1)/Fs);
T9=polyfit(x_s9,filtered_M_V9,order9);
f9=(polyval(T9,x_s9))';
figure;
plot(t9,filtered_M_V9);
ylabel('Torque(Ncm)')
xlabel('Time(s)')
title('Experiment 9')
hold on
plot(t9,f9,'r');
hold off
figure;

% To plot the residuals of the graph:
res9=(filtered_M_V9-(f9));
plot(res9,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 9')

% To print residuals
Sres9=sum((filtered_M_V9-(f9)).^2);
St9=sum((filtered_M_V9-mean(filtered_M_V9)).^2);
RSq9=1-Sres9/St9

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactor9=tinv((cl+1)./2,r9-1);
Sx9=std(res9);
Sx_9=tfactor9*Sx9/r9^0.5;
Calib_error9=Sx_9/mean(filtered_M_V9)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_v9=filtered_M_V9; To find the mean amplitude
F_v9=detrend(filtered_M_V9); %To find the signal amplitude or 
% F_v9=res9; same as detrend with polyorder 1
Fourier_9=fft(F_v9);
Fourier_t9=abs(Fourier_9/length(F_v9));
F_t9 = Fourier_t9(1:(length(F_v9)/2)+1);
F_t9(2:end-1) = 2*F_t9(2:end-1);
l9=Fs*(0:(length(F_v9)/2))/length(F_v9);
figure
plot(l9,F_t9);
ylabel('amplitude(Ncm)')
xlabel('Frequency(Hz)')
title('Experiment 9')

%% For thrust experiments: 1st experiment 
M_Vt1=v2(153000:179500,1);
filtered_M_Vt1_Idx = find((M_Vt1>=900 & M_Vt1<=2000)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt1 = M_Vt1(M_Vt1>=900 & M_Vt1<=2000);
rt1=length(filtered_M_Vt1);
x=max(M_V1)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st1=1:rt1;
ordert1=1;
tt1=((0:length(filtered_M_Vt1)-1)/Fs);
Tt1=polyfit(x_st1,filtered_M_Vt1,ordert1);
ft1=(polyval(Tt1,x_st1))';
figure
plot(tt1,filtered_M_Vt1);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 1')
hold on
plot(tt1,ft1,'r');
hold off
figure;

% To plot the residuals of the graph:
rest1=(filtered_M_Vt1-(ft1));
plot(rest1,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 1')

% To print residuals
Srest1=sum((filtered_M_Vt1-(ft1)).^2);
Stt1=sum((filtered_M_Vt1-mean(filtered_M_Vt1)).^2);
RSq1=1-Srest1/Stt1

% Carrying out uncertainity analysis and print out error at 95% confidence 
tfactort1=tinv((cl+1)./2,rt1-1);
Sxt1=std(rest1);
Sxt_1=tfactort1*Sxt1/rt1^0.5;
Calib_errort1=Sxt_1/mean(filtered_M_Vt1)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_vt1=filtered_M_Vt1; %To find the mean amplitude
F_vt1=detrend(filtered_M_Vt1); % To find the signal amplitude or 
% F_vt1=rest1; %same as detrend with polyorder 1
Fouriert_1=fft(F_vt1);
Fourier_tt1=abs(Fouriert_1/length(F_vt1));
F_tt1 = Fourier_tt1(1:(length(F_vt1)/2)+1);
F_tt1(2:end-1) = 2*F_tt1(2:end-1);
lt1=Fs*(0:(length(F_vt1)/2))/length(F_vt1);
figure
plot(lt1,F_tt1);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 1')

%% For the 2nd experiment
M_Vt2=v2(217000:235500,1);
filtered_M_Vt2_Idx = find((M_Vt2>=1000 & M_Vt2<=2000)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt2 = M_Vt2(M_Vt2>1000 & M_Vt2<=2000);
rt2=length(filtered_M_Vt2);
y=max(M_Vt2)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st2=1:rt2;
ordert2=1;
tt2=((0:length(filtered_M_Vt2)-1)/Fs);
Tt2=polyfit(x_st2,filtered_M_Vt2,ordert2);
ft2=(polyval(Tt2,x_st2))';
figure;
plot(tt2,filtered_M_Vt2);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 2')
hold on
plot(tt2,ft2,'r');
hold off
figure;

% To plot the residuals of the graph:
rest2=(filtered_M_Vt2-(ft2));
plot(rest2,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 2')

% To print residuals
Srest2=sum((filtered_M_Vt2-(ft2)).^2);
Stt2=sum((filtered_M_Vt2-mean(filtered_M_Vt2)).^2);
RSqt2=1-Srest2/Stt2

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactort2=tinv((cl+1)./2,rt2-1);
Sxt2=std(rest2);
Sxt_2=tfactort2*Sxt2/rt2^0.5;
Calib_errort2=Sxt_2/mean(filtered_M_Vt2)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
F_vt2=filtered_M_Vt2; %To find the mean amplitude
% F_vt2=detrend(filtered_M_Vt2); % To find the signal amplitude or 
% F_vt2=rest2; % same as detrend with polyorder 1
Fouriert_2=fft(F_vt2);
Fourier_tt2=abs(Fouriert_2/length(F_vt2));
F_tt2 = Fourier_tt2(1:(length(F_vt2)/2)+1);
F_tt2(2:end-1) = 2*F_tt2(2:end-1);
lt2=Fs*(0:(length(F_vt2)/2))/length(F_vt2);
figure
plot(lt2,F_tt2);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 2')

%% For the 3rd experiment
M_Vt3=v2(267000:282000,1);
filtered_M_Vt3_Idx = find((M_Vt3>=1300 & M_Vt3<=2500)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt3 = M_Vt3(M_Vt3>1300 & M_Vt3<=2500);
rt3=length(filtered_M_Vt3);
z=max(M_Vt3)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st3=1:rt3;
ordert3=1;
tt3=((0:length(filtered_M_Vt3)-1)/Fs);
Tt3=polyfit(x_st3,filtered_M_Vt3,ordert3);
ft3=(polyval(Tt3,x_st3))';
figure;
plot(tt3,filtered_M_Vt3);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 3')
hold on
plot(tt3,ft3,'r');
hold off
figure;

% To plot the residuals of the graph:
rest3=(filtered_M_Vt3-(ft3));
plot(rest3,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 3')

% To print residuals
Srest3=sum((filtered_M_Vt3-(ft3)).^2);
Stt3=sum((filtered_M_Vt3-mean(filtered_M_Vt3)).^2);
RSqt3=1-Srest3/Stt3

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactort3=tinv((cl+1)./2,rt3-1);
Sxt3=std(rest3);
Sxt_3=tfactort3*Sxt3/rt3^0.5;
Calib_errort3=Sxt_3/mean(filtered_M_Vt3)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_vt3=filtered_M_Vt3; % To find the mean amplitude
F_vt3=detrend(filtered_M_Vt3); %To find the signal amplitude or 
% F_vt3=rest3; %same as detrend with polyorder 1
Fouriert_3=fft(F_vt3);
Fourier_tt3=abs(Fouriert_3/length(F_vt3));
F_tt3 = Fourier_tt3(1:(length(F_vt3)/2)+1);
F_tt3(2:end-1) = 2*F_tt3(2:end-1);
lt3=Fs*(0:(length(F_vt3)/2))/length(F_vt3);
figure
plot(lt3,F_tt3);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 3')

%% For the 4th experiment
M_Vt4=v2(321000:349000,1);
filtered_M_Vt4_Idx = find((M_Vt4>=400 & M_Vt4<=1200)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt4 = M_Vt4(M_Vt4>400 & M_Vt4<=1200);
rt4=length(filtered_M_Vt4);
m=max(M_Vt4)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st4=1:rt4;
order4t=1;
tt4=((0:length(filtered_M_Vt4)-1)/Fs);
Tt4=polyfit(x_st4,filtered_M_Vt4,order4t);
ft4=(polyval(Tt4,x_st4))';
figure;
plot(tt4,filtered_M_Vt4);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 4')
hold on
plot(tt4,ft4,'r');
hold off
figure;

% To plot the residuals of the graph:
rest4=(filtered_M_Vt4-(ft4));
plot(rest4,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 4')

% To print residuals
Srest4=sum((filtered_M_Vt4-(ft4)).^2);
Stt4=sum((filtered_M_Vt4-mean(filtered_M_Vt4)).^2);
RSqt4=1-Srest4/Stt4

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactort4=tinv((cl+1)./2,rt4-1);
Sxt4=std(rest4);
Sxt_4=tfactort4*Sxt4/rt4^0.5;
Calib_errort4=Sxt_4/mean(filtered_M_Vt4)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_vt4=filtered_M_Vt4; %To find the mean amplitude
F_vt4=detrend(filtered_M_Vt4); % To find the signal amplitude or 
% F_vt4=rest4; same as detrend with polyorder 1
Fouriert_4=fft(F_vt4);
Fourier_t4=abs(Fouriert_4/length(F_vt4));
F_tt4 = Fourier_t4(1:(length(F_vt4)/2)+1);
F_tt4(2:end-1) = 2*F_tt4(2:end-1);
lt4=Fs*(0:(length(F_vt4)/2))/length(F_vt4);
figure
plot(lt4,F_tt4);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 4')

%% For the 5th experiment
M_Vt5=v2(382000:401500,1);
filtered_M_Vt5_Idx = find((M_Vt5>=600 & M_Vt5<=2000));  % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt5 = M_Vt5(M_Vt5>600 & M_Vt5<=2000);
rt5=length(filtered_M_Vt5);
p=max(M_Vt5)

% To plot the individual data series along with curve ftting (Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st5=1:rt5;
ordert5=1;
tt5=((0:length(filtered_M_Vt5)-1)/Fs);
Tt5=polyfit(x_st5,filtered_M_Vt5,ordert5);
ft5=(polyval(Tt5,x_st5))';
figure;
plot(tt5,filtered_M_Vt5);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 5')
hold on
plot(tt5,ft5,'r');
hold off
figure;

% To plot the residuals of the graph:
rest5=(filtered_M_Vt5-(ft5));
plot(rest5,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 5')

% To print residuals
Srest5=sum((filtered_M_Vt5-(ft5)).^2);
Stt5=sum((filtered_M_Vt5-mean(filtered_M_Vt5)).^2);
RSqt5=1-Srest5/Stt5

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactort5=tinv((cl+1)./2,rt5-1);
Sxt5=std(rest5);
Sxt_5=tfactort5*Sxt5/rt5^0.5;
Calib_errort5=Sxt_5/mean(filtered_M_Vt5)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_vt5=filtered_M_Vt5; % To find the mean amplitude
F_vt5=detrend(filtered_M_Vt5); % To find the signal amplitude or 
% F_vt5=rest5; %same as detrend with polyorder 1
Fouriert_5=fft(F_vt5);
Fourier_tt5=abs(Fouriert_5/length(F_vt5));
F_tt5 = Fourier_tt5(1:(length(F_vt5)/2)+1);
F_tt5(2:end-1) = 2*F_tt5(2:end-1);
lt5=Fs*(0:(length(F_vt5)/2))/length(F_vt5);
figure
plot(lt5,F_tt5);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 5')

%% For the 6th experiment
M_Vt6=v2(438500:453000,1);
filtered_M_Vt6_Idx = find((M_Vt6>=900 & M_Vt6<=2000));  % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt6 = M_Vt6(M_Vt6>900 & M_Vt6<=2000);
rt6=length(filtered_M_Vt6);
o=max(M_Vt6)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st6=1:rt6;
ordert6=1;
tt6=((0:length(filtered_M_Vt6)-1)/Fs);
Tt6=polyfit(x_st6,filtered_M_Vt6,ordert6);
ft6=(polyval(Tt6,x_st6))';
figure;
plot(tt6,filtered_M_Vt6);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 6')
hold on
plot(tt6,ft6,'r');
hold off
figure;

% To plot the residuals of the graph:
rest6=(filtered_M_Vt6-(ft6));
plot(rest6,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 6')

% To print residuals
Srest6=sum((filtered_M_Vt6-(ft6)).^2);
Stt6=sum((filtered_M_Vt6-mean(filtered_M_Vt6)).^2);
RSqt6=1-Srest6/Stt6

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactort6=tinv((cl+1)./2,rt6-1);
Sxt6=std(rest6);
Sxt_6=tfactort6*Sxt6/rt6^0.5;
Calib_errort6=Sxt_6/mean(filtered_M_Vt6)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_vt6=filtered_M_Vt6; % To find the mean amplitude
F_vt6=detrend(filtered_M_Vt6); % To find the signal amplitude or 
% F_vt6=rest6; %same as detrend with polyorder 1
Fouriert_6=fft(F_vt6);
Fourier_tt6=abs(Fouriert_6/length(F_vt6));
F_tt6 = Fourier_tt6(1:(length(F_vt6)/2)+1);
F_tt6(2:end-1) = 2*F_tt6(2:end-1);
lt6=Fs*(0:(length(F_vt6)/2))/length(F_vt6);
figure
plot(lt6,F_tt6);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 6')

%% For the 7th experiment
M_Vt7=v2(493000:525000,1);
filtered_M_Vt7_Idx = find((M_Vt7>=300 & M_Vt7<=2000)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt7 = M_Vt7(M_Vt7>300 & M_Vt7<=2000);
rt7=length(filtered_M_Vt7);
l=max(M_Vt7)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st7=1:rt7;
ordert7=1;
tt7=((0:length(filtered_M_Vt7)-1)/Fs);
Tt7=polyfit(x_st7,filtered_M_Vt7,ordert7);
ft7=(polyval(Tt7,x_st7))';
figure;
plot(tt7,filtered_M_Vt7);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 7')
hold on
plot(tt7,ft7,'r');
hold off
figure;

% To plot the residuals of the graph:
rest7=(filtered_M_Vt7-(ft7));
plot(rest7,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 7')

% To print residuals
Srest7=sum((filtered_M_Vt7-(ft7)).^2);
Stt7=sum((filtered_M_Vt7-mean(filtered_M_Vt7)).^2);
RSqt7=1-Srest7/Stt7

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactort7=tinv((cl+1)./2,rt7-1);
Sxt7=std(rest7);
Sxt_7=tfactort7*Sxt7/rt7^0.5;
Calib_errort7=Sxt_7/mean(filtered_M_Vt7)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_vt7=filtered_M_Vt7; % To find the mean amplitude
F_vt7=detrend(filtered_M_Vt7); % To find the signal amplitude or 
% F_vt7=rest7; %same as detrend with polyorder 1
Fouriert_7=fft(F_vt7);
Fourier_tt7=abs(Fouriert_7/length(F_vt7));
F_tt7 = Fourier_tt7(1:(length(F_vt7)/2)+1);
F_tt7(2:end-1) = 2*F_tt7(2:end-1);
lt7=Fs*(0:(length(F_vt7)/2))/length(F_vt7);
figure
plot(lt7,F_tt7);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 7')

%% For the 8th experiment
M_Vt8=v2(554000:574000,1);
filtered_M_Vt8_Idx = find((M_Vt8>=500 & M_Vt8<=2000)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt8 = M_Vt8(M_Vt8>500 & M_Vt8<=2000);
rt8=length(filtered_M_Vt8);
t=max(M_Vt8)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st8=1:rt8;
ordert8=1;
tt8=((0:length(filtered_M_Vt8)-1)/Fs);
Tt8=polyfit(x_st8,filtered_M_Vt8,ordert8);
ft8=(polyval(Tt8,x_st8))';
figure;
plot(tt8,filtered_M_Vt8);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 8')
hold on
plot(tt8,ft8,'r');
hold off
figure;

% To plot the residuals of the graph:
rest8=(filtered_M_Vt8-(ft8));
plot(rest8,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 8')

% To print residuals
Srest8=sum((filtered_M_Vt8-(ft8)).^2);
Stt8=sum((filtered_M_Vt8-mean(filtered_M_Vt8)).^2);
RSqt8=1-Srest8/Stt8

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactort8=tinv((cl+1)./2,rt8-1);
Sxt8=std(rest8);
Sxt_8=tfactort8*Sxt8/rt8^0.5;
Calib_errort8=Sxt_8/mean(filtered_M_Vt8)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)

% F_vt8=filtered_M_Vt8; % To find the mean amplitude
F_vt8=detrend(filtered_M_Vt8); % To find the signal amplitude or 
% F_vt8=rest8; % same as detrend with polyorder 1
Fouriert_8=fft(F_vt8);
Fourier_tt8=abs(Fouriert_8/length(F_vt8));
F_tt8 = Fourier_tt8(1:(length(F_vt8)/2)+1);
F_tt8(2:end-1) = 2*F_tt8(2:end-1);
lt8=Fs*(0:(length(F_vt8)/2))/length(F_vt8);
figure
plot(lt8,F_tt8);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 8')

%% For the 9th experiment
M_Vt9=v2(607000:622000,1);
filtered_M_Vt9_Idx = find((M_Vt9>=500 & M_Vt9<=2000)); % (https://uk.mathworks.com/matlabcentral/answers/402461-how-to-filter-a-certain-range-of-values-in-a-column-vector-of-thousand-rows)
filtered_M_Vt9 = M_Vt9(M_Vt9>500 & M_Vt9<=2000);
rt9=length(filtered_M_Vt9);
q=max(M_vt9)

% To plot the individual data series along with curve ftting (curvefit.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
x_st9=1:rt9;
ordert9=1;
tt9=((0:length(filtered_M_Vt9)-1)/Fs);
Tt9=polyfit(x_st9,filtered_M_Vt9,ordert9);
ft9=(polyval(Tt9,x_st9))';
figure;
plot(tt9,filtered_M_Vt9);
ylabel('Thrust(N)')
xlabel('Time(s)')
title('Experiment 9')
hold on
plot(tt9,ft9,'r');
hold off
figure;

% To plot the residuals of the graph:
rest9=(filtered_M_Vt9-(ft9));
plot(rest9,'o');
ylabel('residuals')
xlabel('Time(s)')
title('Experiment 9')

% To print residuals
Srest9=sum((filtered_M_Vt9-(ft9)).^2);
Stt9=sum((filtered_M_Vt9-mean(filtered_M_Vt9)).^2);
RSqt9=1-Srest9/Stt9

% Carrying out uncertainity analysis and print out error at 95% confidence (calibrationscript.m, Mark Quinn, Experimental methods unit, University of Mandchester, 2021)
tfactort9=tinv((cl+1)./2,rt9-1);
Sxt9=std(rest9);
Sxt_9=tfactort9*Sxt9/rt9^0.5;
Calib_errort9=Sxt_9/mean(filtered_M_Vt9)*100

% Carrying FFT of each to perform spectral analysis (autocorrelation.m, Mark Quinn, Experimetal Methods unit, University of Manchester, 2021)
% F_vt9=filtered_M_Vt9; % To find the mean amplitude
F_vt9=detrend(filtered_M_Vt9); To find the signal amplitude or 
% F_vt9=rest9; same as detrend with polyorder 1
Fouriert_9=fft(F_vt9);
Fourier_tt9=abs(Fouriert_9/length(F_vt9));
F_tt9 = Fourier_tt9(1:(length(F_vt9)/2)+1);
F_tt9(2:end-1) = 2*F_tt9(2:end-1);
lt9=Fs*(0:(length(F_vt9)/2))/length(F_vt9);
figure
plot(lt9,F_tt9);
ylabel('amplitude(N)')
xlabel('Frequency(Hz)')
title('Experiment 9')